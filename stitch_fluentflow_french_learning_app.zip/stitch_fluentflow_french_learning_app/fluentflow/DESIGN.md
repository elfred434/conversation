---
name: FluentFlow
colors:
  surface: '#11131b'
  surface-dim: '#11131b'
  surface-bright: '#373942'
  surface-container-lowest: '#0c0e16'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#282a32'
  surface-container-highest: '#32343d'
  on-surface: '#e1e2ed'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#e1e2ed'
  inverse-on-surface: '#2e3039'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#5de6ff'
  on-secondary: '#00363e'
  secondary-container: '#00cbe6'
  on-secondary-container: '#00515d'
  tertiary: '#ffb596'
  on-tertiary: '#581e00'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#a2eeff'
  secondary-fixed-dim: '#2fd9f4'
  on-secondary-fixed: '#001f25'
  on-secondary-fixed-variant: '#004e5a'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#11131b'
  on-background: '#e1e2ed'
  surface-variant: '#32343d'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: '1.65'
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  max-width: 780px
  unit: 8px
  section-gap: 64px
  stack-gap: 24px
  container-padding: 32px
---

## Brand & Style
The design system embodies a meditative, immersive approach to language acquisition, drawing inspiration from the depths of the ocean. The brand personality is patient, fluid, and restorative, aiming to lower the cognitive "affective filter" often associated with learning a new language. 

The aesthetic is a refined blend of **Glassmorphism** and **Minimalism**. It utilizes deep chromatic layering to simulate water depth, creating a low-stimulation environment that encourages deep focus. Interaction patterns should mimic the slow-motion weightlessness of underwater movement, prioritizing ease and tranquility over urgency.

## Colors
The palette is rooted in a "Deep Navy" abyss, providing a stable, dark foundation that reduces eye strain. Brand expression is achieved through light rather than solid pigment, utilizing soft radial glows of #2563EB and #22D3EE at low opacities (8-12%) to create a sense of bioluminescence.

The **Signature Gradient** is reserved for high-impact elements: primary calls to action, progress indicators, and significant data points. Text colors are carefully balanced for high legibility against dark backgrounds without being harsh, using cool-toned whites and muted slate blues.

## Typography
This design system utilizes **Inter** exclusively to maintain a clean, systematic, and modern feel. The typography is defined by generous line heights (1.65 for body text) to ensure French accents (cedillas, circumflexes) have ample room to breathe and are easily distinguishable.

Headlines should be used sparingly to maintain the quiet atmosphere. For French-language content, always ensure `font-variant-numeric: tabular-nums` is active for countdowns or progress percentages to prevent layout jitter during timed exercises.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy, centered on a single column with a maximum width of 780px. This narrow focus minimizes eye travel and mimics the singular focus of a meditation session.

Vertical rhythm is airy and generous. Use large "section-gaps" (64px) to separate distinct learning modules and "stack-gaps" (24px) for content within cards. On mobile devices, the max-width is ignored in favor of 20px side margins, but the single-column focus remains absolute to prevent distractions.

## Elevation & Depth
Depth is created through **Glassmorphism** rather than traditional shadows. Surfaces are defined by their translucency and the "refraction" of the background.

- **Surface Layer:** `rgba(19, 29, 58, 0.55)` fill with a `12px` backdrop-blur. 
- **Edges:** A `1px` solid border at `rgba(93, 120, 190, 0.28)` creates a subtle "glint" on the edge of the glass, suggesting a physical object suspended in water.
- **Z-Index:** Content should feel like it is floating at different depths. Higher-priority modals should increase the backdrop-blur to `20px` and slightly increase the border opacity to `0.4` to simulate being "closer" to the surface.

## Shapes
The shape language is organic and soft. A standard radius of `20px` (represented by `rounded-xl` in this system) is used for all main cards and containers. This high degree of rounding removes any visual "sharpness," contributing to the safe, calm environment.

Interactive elements like buttons and input fields should utilize the same `20px` radius to maintain consistency. Subtle ocean-wave motifs (sinusoidal paths) may be used as decorative dividers or progress bar fills.

## Components
- **Primary Buttons:** Styled with the Signature Gradient. Text is high-contrast white. Hover states should include a subtle `0.5rem` outer glow in #22D3EE.
- **Glass Cards:** Used for lesson content. These must always have the 12px blur and 1px border. No drop shadows.
- **Input Fields:** Semi-transparent dark fills with the standard 20px radius. The border glows with the primary color when focused.
- **Progress Bubbles:** Instead of traditional linear bars, use soft, floating circular indicators that fill with the gradient as the user progresses through a French lesson.
- **Chips:** Small, pill-shaped elements with a `rgba(256, 256, 256, 0.05)` background and secondary text color for tags like "Grammaire" or "Vocabulaire."
- **Lists:** Items separated by thin, low-opacity lines (10% white). Each item should have a slightly increased vertical padding (16px) to maintain the airy feel.